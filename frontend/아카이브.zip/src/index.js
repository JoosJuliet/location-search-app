import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import {EmployeeMainPage, CompletedResortPage} from './pages/employee'
import {ManagerMainPage, RegistResortPage, RegistEventPage, BettingPage} from './pages/manager'
import {NotFound} from './pages/notFound/NotFound'

const rounting=(
  <Router>
    <div>
      <Switch>
        <Route exact path="/" component={App}/>
        <Route exact path="/employee" component={EmployeeMainPage}/>
          <Route path="/employee/:employee_id/completed-resorts" component={CompletedResortPage}/>
        <Route exact path="/manager" component={ManagerMainPage}/>
          <Route path="/manager/register-resorts" component={RegistResortPage}/>
          <Route path="/manager/register-events" component={RegistEventPage}/>
          <Route path="/manager/event/:event_id" component={BettingPage}/>
        
        <Route component={NotFound}/>
      </Switch>
    </div>
  </Router>
)

ReactDOM.render(rounting, document.getElementById('root'));
// /event/:event_id부분 해야한다.