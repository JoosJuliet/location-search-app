import React from 'react'

class CheckListItem extends React.Component {
  constructor (props){
    super ();
    this.state = {
      checked: false
    };
  }
  handleClick = (e) => {
    this.setState({
      checked: !this.state.checked
    });
    if(this.state.checked){
      this.props.handleRemove(this.props.info);
    }
    else{
      this.props.handleCreate(this.props.info);
    }
  }
  render (){
    let text = this.state.checked ?
      <strike>
        {this.props.displayMessage}
      </strike>
      : this.props.displayMessage;
    return (
        <div className="row">
          <div className="col-md-12">
            <input type="checkbox" onClick={this.handleClick} />&nbsp;
              {text}
            <hr />
          </div>
        </div>
    );
  }
}

export default CheckListItem;
