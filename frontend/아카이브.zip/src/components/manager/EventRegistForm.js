import React from 'react'
import { Container, Button,Form } from 'react-bootstrap'
import CheckListItem from '../common/CheckListItem'
import { saveData, getData } from '../../lib/dbService';
import { withRouter } from 'react-router-dom';

class EventRegistForm extends React.Component {
  state = {
	   startDateTime: '',
	   endDateTime : '',
	   writer : '',
	   resort :  [
      {
          "createdDateTime": "",
          "modifiedDateTime": "",
          "id": -1,
          "checkInDate": "",
          "checkInYearMonth": null,
          "name": "",
          "location": "",
          "roomType": "",
          "employees": [
          ]
      },
    ],
    infos: []
  }
  componentWillMount(){
    this.fetchInfos();
  }
  fetchInfos = (e) => {
    getData('http://localhost:8080/resorts')
    .then(response => {
      this.setState({infos: response.data});
    })
    .catch(error => {
      console.log(error.response);
    })

  }
  handleCreate = (checkedItem) => {
    const { resort } = this.state;
    this.setState({
      resort: resort.concat(checkedItem)
    })
  }
  handleRemove = (checkedItem) => {
    const { resort } = this.state;
    this.setState({
      resort: resort.filter(item => item.id !== checkedItem.id)
    })
  }

  handleChangeFor = (propertyName) => (e) =>{
    this.setState({ [propertyName]: e.target.value })
  }
  handleSubmit = (e) => {
    saveData('http://localhost:8080/events', this.state)
    .then(response => {
      console.log('response', response);

      this.props.history.push('/manager')
      
    })
    .catch(error => {
      console.log(error.response);
    })
  }

  handleChecked = (checked) => {
    this.setState({resort: checked});
  }
  render(){
    const mapToItems = (infos) => {
      return infos.map((info,i) => {
        return (<CheckListItem
                  handleCreate={this.handleCreate}
                  handleRemove={this.handleRemove}
                  // handleUpdate={this.handleUpdate}
                  key = {i}
                  index = {i}
                  info={info} 
                  displayMessage={"["+info.location+"]"+ info.name + "  체크인 시작 날짜 :"+info.checkInDate}/>)
      })
    }
    return (
      <Container>
        <Form>
          <Form.Group controlId='formWriter'>
          <Form.Label>작성자</Form.Label>
          <Form.Control onChange={this.handleChangeFor('writer')} value = {this.state.writer} type="text" placeholder="작성자" />
          </Form.Group>

          <Form.Group controlId="formStartDateTime">
          <Form.Label>시작 날짜</Form.Label>
          <Form.Control onChange={this.handleChangeFor('startDateTime')} value = {this.state.startDateTime} type="text" placeholder="startDateTime" />
          </Form.Group>

          <Form.Group controlId="formEndDateTime">
          <Form.Label>종료 날짜</Form.Label>
          <Form.Control onChange={this.handleChangeFor('endDateTime')} value = {this.state.endDateTime} type="text" placeholder="endDateTime" />
          </Form.Group>

          <Form.Group controlId="formResorts">
          <Form.Label>리조트 리스트</Form.Label>
          {mapToItems(this.state.infos)}
          {/* todo id뿐만 아니라 name도 보여줘야한다. */}
          </Form.Group>

          <Button onClick={this.handleSubmit} variant="primary">
          등록하기
          </Button>
        </Form>
      </Container>
    )
  }
}
export default withRouter(EventRegistForm);

