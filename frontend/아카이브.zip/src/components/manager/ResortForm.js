import React from 'react'
import { Container, Button,Form } from 'react-bootstrap'
import { saveData } from '../../lib/dbService';
import {withRouter} from 'react-router-dom';

class ResortForm extends React.Component {
  state = {
    name: '',
    location: '',
    roomType: '',
    checkInDate: '',
    checkInYearMonth: '',
  }

  handleChangeFor = (propertyName) => (e) =>{
    this.setState({ [propertyName]: e.target.value })
  }
  handleSubmit = async(e) => {
    saveData('http://localhost:8080/resorts', this.state)
    .then(response => {
      console.log(response);
      this.props.history.push('/manager')
    })
    .catch(error => {
      console.log(error.response);
    })
  }

  render(){
    return (
      <Container>
        <Form>
          <Form.Group controlId='formEmployeeName'>
          <Form.Label>리조트명</Form.Label>
          <Form.Control onChange={this.handleChangeFor('name')} value = {this.state.name} type="text" placeholder="리조트명" />
          </Form.Group>

          <Form.Group controlId="formEmployeeLocation">
          <Form.Label>위치</Form.Label>
          <Form.Control onChange={this.handleChangeFor('location')} value = {this.state.location} type="text" placeholder="위치" />
          </Form.Group>

          <Form.Group controlId="formEmployeeRoomtype">
          <Form.Label>룸타입</Form.Label>
          <Form.Control onChange={this.handleChangeFor('roomType')} value = {this.state.roomType} name = "roomType" type="text" placeholder="룸타입" />
          </Form.Group>

          <Form.Group controlId="formEmployeeCheckInDate">
          <Form.Label>체크인날짜</Form.Label>
          <Form.Control onChange={this.handleChangeFor('checkInDate')} value = {this.state.checkInDate} name = "checkInDate" type="text" placeholder="체크인날짜" />
          </Form.Group>

          <Form.Group controlId="formEmployeeCheckInYearMonth">
          <Form.Label>체크인YearMonth</Form.Label>
          <Form.Control onChange={this.handleChangeFor('checkInYearMonth')} value = {this.state.checkInYearMonth} name = "checkInYearMonth" type="text" placeholder="체크인날짜" />
          </Form.Group>

          <Button onClick={this.handleSubmit} variant="primary">
          등록하기
          </Button>
        </Form>
      </Container>
    )
  }
}
export default withRouter(ResortForm);
