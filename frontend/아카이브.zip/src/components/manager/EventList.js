import React from 'react'
import { Button } from 'react-bootstrap'
import { getData } from '../../lib/dbService';
import {withRouter} from 'react-router-dom';

class Item extends React.Component {
  render (){
    return (
        <div className="row">
          <div className="col-md-12">
              <Button onClick={(e) => this.props.handleClick(e, this.props.id)}>확인</Button> {this.props.message}
            <hr />
          </div>
        </div>
    );
  }
}

class EventList extends React.Component {
  state = {
    items: [],
    checked: []
  }
  componentWillMount(){
    this.fetchEmployeeInfos();
  }
  fetchEmployeeInfos =(e) => {
    getData('http://localhost:8080/events')
    .then(response => {
      this.setState({items: response.data });
    })
    .catch(error => {
      console.log(error.response);
    })

  }
  handleClick = (e, key) => {
    this.props.history.push('/manager/event/'+key)
    e.preventDefault();
  }
  render (){
    const mapToItems = (infos) => {
      if(infos.length !== 0){

        console.log('info.startDateTime.toLocaleDateString()', 
          infos[0].startDateTime, typeof infos[0].startDateTime
          , new Date(infos[0].startDateTime).toUTCString()  )
      }

      return infos.map((info, i) => {

        return (<Item
                  key = {i}
                  id = {info.id}
                  message={" 책임자 : " + info.writer +"     "+ info.startDateTime + " - " + info.endDateTime} 
                  handleClick={this.handleClick}/>)
      })
    }
    return (
      <div>
        <h4>{mapToItems(this.state.items)}</h4>
      </div>
    );
  }
}
export default withRouter(EventList);
