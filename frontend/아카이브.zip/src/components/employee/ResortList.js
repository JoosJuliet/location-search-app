import React from 'react'
import { Button } from 'react-bootstrap'
import CheckListItem from '../common/CheckListItem'
import { saveData, getData } from '../../lib/dbService';
import {withRouter} from 'react-router-dom';

class ResortList extends React.Component {
  state = {
    checked: [],
    infos: []
  }
  componentWillMount(){
    this.fetchInfos();
  }
  fetchInfos = (e) => {
    getData('http://localhost:8080/employees/'+this.props.employee_id)
    .then(response => {
      this.setState({infos: response.data});
    })
    .catch(error => {
      console.log(error.response);
    })

  }
  handleCreate = (checkedItem) => {
    const { checked } = this.state;
    this.setState({
      checked: checked.concat(checkedItem)
    })
  }
  handleRemove = (checkedItem) => {
    const { checked } = this.state;
    this.setState({
      checked: checked.filter(item => item.id !== checkedItem.id)
    })
  }
  handleUpdate = (id, data) => {
    const { checked } = this.state;
    this.setState({
      // checked: checked.map(
      //   info => id === info.id
      //     ? { ...info, ...data } // 새 객체를 만들어서 기존의 값과 전달받은 data 을 덮어씀
      //     : info // 기존의 값을 그대로 유지
      // )
    })
  }
  submitInfos = (checked_items, callback) => {
    saveData('http://localhost:8080/employees/'+this.props.employee_id, checked_items)
    .then(response => {
      console.log(response);
      callback();
    })
    .catch(error => {
      console.log(error.response);
    })

  }
  handleClick = (e) => {
    this.submitInfos(this.state.checked, () => { 
      this.props.history.push('/employee/'+this.props.employee_id+'/completed-resorts')
    });
    e.preventDefault();
  }
  render (){
    const mapToItems = (infos) => {
      return infos.map((info,i) => {
        return (<CheckListItem
                  handleCreate={this.handleCreate}
                  handleRemove={this.handleRemove}
                  // handleUpdate={this.handleUpdate}
                  key = {i}
                  index = {i}
                  info={info} 
                  displayMessage = {"["+info.location+"]"+ info.name + "  체크인 시작 날짜 :"+info.checkInDate  } />)
      })
    }

    return (
      <div>
        {mapToItems(this.state.infos)}
        <Button onClick={this.handleClick}>체크 완료</Button>
      </div>
    );
  }
}

export default withRouter(ResortList);
