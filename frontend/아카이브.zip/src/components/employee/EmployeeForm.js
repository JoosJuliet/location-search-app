import React from 'react'
import { Button,Form } from 'react-bootstrap'
import { saveData } from '../../lib/dbService'


class EmployeeForm extends React.Component {
  state = {
    name: '',
    employeeId: '',
    mail: ''
  }

  handleChangeFor = (propertyName) => (e) =>{
    this.setState({ [propertyName]: e.target.value })
  }
  handleSubmit = (e) => {
    saveData('http://localhost:8080/employees', this.state)
    .then(response => {
      this.props.handleResortList(response.data.id)
      console.log('response', this.props.handleResortList)
    })
    .catch(error => {
        console.log('error.response', error.response);
    })
  }

  render(){
    return (
      <div>
        <Form>
          <Form.Group controlId='formEmployeeName'>
          <Form.Label>사원이름</Form.Label>
          <Form.Control onChange={this.handleChangeFor('name')} value = {this.state.name} type="text" placeholder="이름" />
          </Form.Group>

          <Form.Group controlId="formEmployeeEmployeeId">
          <Form.Label>사번</Form.Label>
          <Form.Control onChange={this.handleChangeFor('employeeId')} value = {this.state.employeeId} type="employeeId" placeholder="사번" />
          </Form.Group>

          <Form.Group controlId="formEmployeeEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control onChange={this.handleChangeFor('mail')} value = {this.state.mail} name = "mail" type="mail" placeholder="메일" />
          </Form.Group>

          <Button onClick={this.handleSubmit} variant="primary">
          Submit
          </Button>
        </Form>
      </div>
    )
  }
}
export default EmployeeForm
