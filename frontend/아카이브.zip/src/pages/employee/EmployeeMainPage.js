import React from 'react'
import EmployeeForm from '../../components/employee/EmployeeForm'
import ResortList from '../../components/employee/ResortList'


import { Container } from 'react-bootstrap'

export class EmployeeMainPage extends React.Component{
  state = {
    employee_id: -1,
    visible_resort_list: false,
  }
  handleResortList = (id) => {
    this.setState({employee_id: id, visible_resort_list: true});
  }
  render(){
    return(
      <Container>
        <EmployeeForm handleResortList={(id) => this.handleResortList(id)}/>
        {(this.state.visible_resort_list) ? <ResortList employee_id={this.state.employee_id}/> : null}
      </Container>
    )
  }
}
// import React, {Component} from 'react'
//
// export class EmployeeMainPage extends Component{
//   handleSubmit = (e)=>{
//     e.preventDefault()
//     this.props.history.push("/employee/competed")
//   }
//   render(){
//     return(
//       <div>
//         <h1>EmployeeMainPage</h1>
//         <form onSubmit={this.handleSubmit}>
//           <input type="text"/><br/>
//           <input type="text"/><br/>
//           <input type="text"/>
//           <button>next</button>
//         </form>
//       </div>
//     )
//   }
// }
