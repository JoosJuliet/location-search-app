import React from 'react'
import { Container } from 'react-bootstrap'
import { getData } from '../../lib/dbService';

export class Item extends React.Component {
    render (){
      return (
          <div className="row">
            <div className="col-md-12">
                {this.props.text}
              <hr />
            </div>
          </div>
      );
    }
  }
  
  export class CompletedResortPage extends React.Component {
    state = {
      items: [],
      checked: []
    }
    componentWillMount(){
      this.fetchDatas();
    }
    fetchDatas =(e) => {
      getData('http://localhost:8080/employees/'+this.props.match.params.employee_id+'/resorts')
      .then(response => {
        this.setState({items: response.data });
      })
      .catch(error => {
        console.log(error.response);
      })
  
    }
    render (){
      const mapToItems = (infos) => {
        return infos.map((info, i) => {
          return (<Item
                    key = {i}
                    text={"["+info.location+"]"+ info.name + "  체크인 시작 날짜 :"+info.checkInDate} />)
        })
      }
      return (
        <Container>
          <h4>{mapToItems(this.state.items)}</h4>
        </Container>
      );
    }
  }
  
