import React from 'react'
import EventList from '../../components/manager/EventList'
import { Container, Button } from 'react-bootstrap'

export const ManagerMainPage = (props) => {
  return(
    <Container>
      <Button href="/manager/register-resorts" variant="primary" size="lg">resorts등록하기</Button>
      <Button href="/manager/register-events" variant="primary" size="lg">events등록하기</Button>
      <EventList/>
    </Container>
  )
}
