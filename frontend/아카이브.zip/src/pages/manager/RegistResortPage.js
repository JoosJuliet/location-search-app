import React from 'react'
import ResortForm from '../../components/manager/ResortForm'

export const RegistResortPage = () => {
  return (
    <h1>
      <ResortForm/>
    </h1>
  )
}
