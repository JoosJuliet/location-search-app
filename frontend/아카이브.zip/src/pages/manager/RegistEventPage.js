import React from 'react'
import { Container, Button } from 'react-bootstrap'
import EventRegistForm from '../../components/manager/EventRegistForm'

export const RegistEventPage = (props) => {
  return(
    <Container>
      <EventRegistForm />
    </Container>
  )
}
