export {ManagerMainPage} from './ManagerMainPage'
export {RegistResortPage} from './RegistResortPage'
export {BettingPage} from './BettingPage'
export {RegistEventPage} from './RegistEventPage'
