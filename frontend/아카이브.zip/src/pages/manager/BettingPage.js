import React from 'react'
import { Container, Button } from 'react-bootstrap'
import { getData } from '../../lib/dbService';

class EmployeeItem extends React.Component {
    render (){
      return (
          <div className="row">
            <div className="col-md-12">
                {this.props.text}
              <hr />
            </div>
          </div>
      );
    }
  }

class Item extends React.Component {
    state = {
        items: {
            "createdDateTime": "",
            "modifiedDateTime": "",
            "id": -1,
            "name": "",
            "employeeId": "",
            "mail": "",
            "resomeDate": "",
            "anantiDate": ""
        }
    }
    fetchDatas =(e) => {
        getData('http://localhost:8080/events/'+this.props.info.name+'/'+this.props.info.checkInDate)
        .then(response => {
            this.setState({items: response.data });
        })
        .catch(error => {
            console.log(error.response);
        })

    }
    render (){
        const mapToItems = (infos) => {
            return infos.map((info, i) => {
                return (<EmployeeItem
                        key = {i}
                        text={"사번 : "+info.employeeId + " 사원 이름 : "+info.name + " 사원 메일 : "+info.mail} />)
            })
        }
      return (
          <div className="row">
            <div className="col-md-12">
                <h3>
                    {this.props.info.checkInDate} {this.props.info.name} 
                    <Button onClick={this.fetchDatas}>추첨하기</Button>
                    {(this.state.items.name) ? "추첨결과 : "+this.state.items.name : ''}
                </h3><hr/>
                {mapToItems(this.props.info.employees)} 
              <hr />
            </div>
          </div>
      );
    }
  }
  
export class BettingPage extends React.Component {
    state = {
        items: {
            "id": -1,
            "startDateTime": "",
            "endDateTime": "",
            "writer": "",
            "resorts": [
                {
                    "createdDateTime": "",
                    "modifiedDateTime": "",
                    "id": -1,
                    "checkInDate": "",
                    "checkInYearMonth": null,
                    "name": "",
                    "location": "",
                    "roomType": "",
                    "employees": [
                    ]
                }
            ]
        },
        checked: []
    }
    componentWillMount(){
        this.fetchDatas();
    }
    fetchDatas =(e) => {
        getData('http://localhost:8080/events/'+this.props.match.params.event_id)
        .then(response => {
            this.setState({items: response.data });
        })
        .catch(error => {
            console.log(error.response);
        })

    }
    render (){
        const { items } = this.state;

        const mapToItems = (infos) => {
            return infos.map((info, i) => {
                return (<Item
                        key = {i}
                        info={info} />)
            })
        }

        return (
            <Container>
                <h4>{items.checkInDate}</h4>
                {mapToItems(items.resorts)}
            </Container>
        );
    }
}

