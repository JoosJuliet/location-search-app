import React from 'react'

export const NotFound = () => <h1>Not Found</h1>
